class AppString {
  static const baseUrl = "https://myfestivalcard.glitch.me/api/festival/list";

  //user detail

  static const addYourHome = "+ Add your home";
  static const selectCity = "Select City";
  static const addHome = "Add Home";
  static const city = "City";
  static const society = "Society";
  static const searchYrSocietyNm = "Search Your Society Name ";


}
