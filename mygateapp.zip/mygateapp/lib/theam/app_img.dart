class AppImage {
  static const imageRoot = "asset/image/";


  static const firstimage= imageRoot + "f.png";

}
